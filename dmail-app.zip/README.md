# dmail-app

Building damil app using React, Tailwind CSS, and TypeScript 🔥

<img src="/public/compose.png" alt="screenshot"/>

<img src="/public/inbox.png" alt="screenshot"/>

# Installation

```javascript
cd YOUR-PROJECT-FOLDER
yarn  // install all packages dependencies
yarn start  // run 
```
