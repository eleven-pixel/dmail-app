import React from 'react';

const Sent: React.FC = () => {
  return (
     <>
     <div className="mt-4 w-full h-full">
      <div className= "grid grid-cols-1 gap-2" >
      <p> No message yet!</p>
      </div>
      </div>
     </>
  );
};

export default Sent;
